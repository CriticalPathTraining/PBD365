﻿using System;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.PowerBI.Api.V2;
using Microsoft.Rest;
using System.IO;
using System.Diagnostics;
using Microsoft.PowerBI.Api.V2.Models;

namespace PowerBiEmbeddedScratchpad.Models {


  class PbiEmbeddedManager { 

    #region "private implemntation details"

    static string clientId = "447a9347-5c3b-4d95-bcab-38e9521bb3aa";
   // static string redirectUrl = "https://locahost/app1234";

    private const string workspaceId = "139cca87-703a-4829-8da8-87eaa279cba3";
    private const string datasetId = "c559566f-a3a1-472c-a698-b13c503c264a";
    private const string reportId = "b31e5bb0-970d-4191-951e-63c0ba433003";
    private const string dashboardId = "7e26c4a6-96ef-415f-a6e3-13e13ecf5f3f";

    private static string aadAuthorizationEndpoint = "https://login.windows.net/common/oauth2/authorize";
    private static string resourceUriPowerBi = "https://analysis.windows.net/powerbi/api";
    private static string urlPowerBiRestApiRoot = "https://api.powerbi.com/";

    private static string GetAccessToken() {

      // create new authentication context 
      var authenticationContext =
        new AuthenticationContext(aadAuthorizationEndpoint);

      // use authentication context to trigger user sign-in and return access token 
      //var userAuthnResult =
      //  authenticationContext.AcquireTokenAsync(resourceUriPowerBi,
      //                                          clientId,
      //                                          new Uri(redirectUrl),
      //                                          new PlatformParameters(PromptBehavior.Auto)).Result;

      var userAuthnResult =
       authenticationContext.AcquireTokenAsync(resourceUriPowerBi,
                                               clientId,
                                               new UserPasswordCredential("student@cpt0328.onMicrosoft.com",
                                                                          "Pa$$word!")).Result;



      // return access token to caller
      return userAuthnResult.AccessToken;

    }

    private static PowerBIClient GetPowerBiClient() {
      var tokenCredentials = new TokenCredentials(GetAccessToken(), "Bearer");
      return new PowerBIClient(new Uri(urlPowerBiRestApiRoot), tokenCredentials);
    }

    #endregion


    public static ReportEmbeddingData GetReportEmbeddingData(bool thirdPartyEmbedding = true) {

      PowerBIClient pbiClient = GetPowerBiClient();

      var report = pbiClient.Reports.GetReportInGroup(workspaceId, reportId);
      var embedUrl = report.EmbedUrl;
      var reportName = report.Name;

      GenerateTokenRequest generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view");
      string embedToken = pbiClient.Reports.GenerateTokenInGroup(workspaceId, report.Id, generateTokenRequestParameters).Token;

      return new ReportEmbeddingData {
        reportId = reportId,
        reportName = reportName,
        embedUrl = embedUrl,
        accessToken = embedToken
      };

    }

    public static NewReportEmbeddingData GetNewReportEmbeddingData(bool thirdPartyEmbedding = true) {
      
      string embedUrl = "https://app.powerbi.com/reportEmbed?groupId=" + workspaceId;

      PowerBIClient pbiClient = GetPowerBiClient();

      GenerateTokenRequest generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "create", datasetId: datasetId);
      string embedToken = pbiClient.Reports.GenerateTokenForCreateInGroup(workspaceId, generateTokenRequestParameters).Token;

      return new NewReportEmbeddingData {workspaceId=workspaceId ,datasetId=datasetId, embedUrl = embedUrl, accessToken = embedToken };
    }

    public static NewReportEmbeddingData GetNewReportEmbeddingDataFirstParty(bool thirdPartyEmbedding = true) {

      string embedUrl = "https://app.powerbi.com/reportEmbed?groupId=" + workspaceId;

      return new NewReportEmbeddingData {
        workspaceId = workspaceId,
        datasetId = datasetId,
        embedUrl = embedUrl,
        accessToken = GetAccessToken()
      };

    }

    public static DashboardEmbeddingData GetDashboardEmbeddingData(bool thirdPartyEmbedding = true) {

      PowerBIClient pbiClient = GetPowerBiClient();

      var dashboard = pbiClient.Dashboards.GetDashboardInGroup(workspaceId, dashboardId);
      var embedUrl = dashboard.EmbedUrl;
      var dashboardDisplayName = dashboard.DisplayName;

      GenerateTokenRequest generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view");
      string embedToken = pbiClient.Dashboards.GenerateTokenInGroup(workspaceId, dashboardId, generateTokenRequestParameters).Token;

      return new DashboardEmbeddingData {
        dashboardId= dashboardId,
        dashboardName = dashboardDisplayName,
        embedUrl = embedUrl,
        accessToken = embedToken
      };

    }

    public static DashboardTileEmbeddingData GetDashboardTileEmbeddingData(bool thirdPartyEmbedding = true) {

      PowerBIClient pbiClient = GetPowerBiClient();

      var tiles = pbiClient.Dashboards.GetTilesInGroup(workspaceId, dashboardId).Value;
      var tile = tiles[0];
      var tileId = tile.Id;
      var tileTitle = tile.Title;
      var embedUrl = tile.EmbedUrl;
      
      GenerateTokenRequest generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view");
      string embedToken = pbiClient.Tiles.GenerateTokenInGroup(workspaceId, dashboardId, tileId, generateTokenRequestParameters).Token;

      return new DashboardTileEmbeddingData {
        dashboardId = dashboardId,
        TileId = tileId,
        TileTitle = tileTitle,
        embedUrl = embedUrl,
        accessToken = embedToken
      };

    }

  }
}
