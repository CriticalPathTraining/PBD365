﻿using System;
using PowerBiEmbeddedScratchpad.Models;

namespace PowerBiEmbeddedScratchpad {
  class Program {
    static void Main() {

      PageGenerator.GenerateReportPage();
      //PageGenerator.GenerateReportWithToolbarPage();
      //PageGenerator.GenerateNewReportPage();
      //PageGenerator.GenerateNewReportPageFirstParty();
      //PageGenerator.GenerateDashboardPage();
      //PageGenerator.GenerateDashboardTilePage();

    }

  }
}
